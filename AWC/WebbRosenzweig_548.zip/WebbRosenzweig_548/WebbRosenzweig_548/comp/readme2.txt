3/2/04
readme2.txt

GLOBAL SOIL TEXTURE AND DERIVED WATER-HOLDING CAPACITIES (WEBB ET AL.). 
Robert W. Webb, Cynthia E. Rosenzweig, and Elissa R. Levine
(please see readme.txt for a listing of the files associated with
this data set.)

The original data arrived as four columns in an ASCII file.  The
four columns represented profile depth, percent sand, percent silt
and percent clay.  We developed a program to assign the correct
Zobler soil type (106), continent code (10), and profile number (15)
to each record in the ascii file, based upon the documentation and
formatting information found in the FORTRAN code companion file.

The result is a comma-delimited ASCII file (new_soildata.csv) containing 
16050 data records and a header record.  The attribute headings are as follows:  
Zobler soil type (ztype), continent code (cont), horizon number (profile),
horizon depth (depth), percent sand (sand), percent silt (silt), and
percent clay (clay).  Please see the companion files zobler_106.txt and
zcontinent.txt for a description of the soil types (106) and the continent
codes (10) used in this data set.  

Please see the readme.txt for a more complete description of 
what these values represent.

As a courtesy to our users, we have derived ARC/INFO grids from the ASCII
file new_soildata.csv.  There are 15 global grids included in this data set.  
Each grid represents a soil horizon (named profile*m), with profile1m representing 
the horizon closest to the soil surface and profile15m representing the 
deepest horizon possible.  No soil type within this data set contained more 
than 14 horizons. However, empty records were retained and flagged with a 
value of -1.  For example, if a given soil type contained 13 soil horizons, 
the first grid (profile1m) would record a depth of 0 and the corresponding 
sand, silt, and clay proportions for the first horizon, the second grid 
(profile2m) would record the contact depth of the second horizon as well as 
the proportion sand, silt, and clay for the second horizon, and so on.  The 
thirteenth grid (profile13m) would record the contact depth of the thirteenth 
horizon and the proportion sand, silt, and clay for the thirteenth (and final) 
horizon, and the fourteenth grid (profile14m) would record the depth of
the BOTTOM of the thirteenth horizon and carry the flagged value of -1 for 
the values of sand, silt, and clay.  The fifteenth grid (profile15m) would
carry the flagged value of -1 for the depth, sand, silt, and clay attributes. 

Each grid contains the following attributes in its value attribute table (VAT):

VALUE - an arbitrary but unique identifier assigned during the creation of the
        grid
COUNT - the number of cells within the grid assigned to a given VALUE
CONTNGDC - continent code (1-10)
ZOBLER_106 - Zobler soil type
UNIQUE_ID - a key-id created by combining the CONTNGDC_ZOBLER_106
DEPTH* - soil depth (meters); the first value is 0 for a given soil type
SAND* - percent sand for a given horizon 
SILT* - percent silt for a given horizon
CLAY* - percent clay for a given horizon

These grids were created by combining a grid containing the continent codes and
a grid containing the Zobler soil types.  The combination of these values was
used as a relate item to link back to the data stored in file new_soildata.csv.  
Please note that 'ocean values' (cont code 0, zobler soil type 0) were 
assigned the NODATA value. 

Export files (*e00) were created from the grids using the EXPORT command in 
ARC/INFO.  The export files were compressed using the gzip utility in UNIX.

global grid specifics:
units = decimal degrees
rows = 180
columns = 360

***Note:  the depth data associated with the third soil horizon (profile3m) 
included anomalous values of -0.01.  Based upon an evaluation of the 
subsequent horizons, it was determined that these values should be flagged with
-1 and not -0.01.  The values were changed accordingly.
