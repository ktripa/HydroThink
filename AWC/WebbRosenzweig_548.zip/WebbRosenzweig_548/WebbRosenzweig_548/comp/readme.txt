readme.txt
4/5/04

DESCRIPTION:   A GLOBAL DATA SET OF SOIL PARTICLE SIZE PROPERTIES          
                                                                  

CITATION:                                                                      
----------
         Webb, R. W., C. E. Rosenzweig, and E. R. Levine. 2000.
	     Global Soil Texture and Derived Water-Holding Capacities (Webb et al.).
             Data set.  Available on-line [http://www.daac.ornl.gov] from
             Oak Ridge National Laboratory Distributed Active Archive Center,
             Oak Ridge, Tennessee, U.S.A. 
                                                                                
COMMENTS:                                                                       
---------

       This data set was orignially offered as several ASCII files with data
       arranged in long columns.  

       Original files include:

       contizob.ler - contains 2 columns of data including continent code and
                      Zobler soil type (106);
       soildata.new - contains 4 columns of data including profile depth,
                      percent sand, percent silt, and percent clay;
       globsoil.dep - soil profile thickness (cm) ASCII array;
       globsoil.all - potential storage of water in the soil profile (cm) 
                      ASCII array;
       globsoil.roo - potential storage of water in the root zone (mm)
                      ASCII array;
       globsoil.tex - potential storage of water derived from soil texture (mm)
                      ASCII array;
       giss2h2o.map - water-holding capacity used in the GISS general circulation
                      model (Model II) (mm) ASCII array; and
       soilasci.for - FORTRAN code and notes that accompanied the original data files.

       These files are available with the original documentation in a
       compressed tar archive in our data pool:
       http://daac.ornl.gov/daacdata/global_soil/WebbRosenzweig/comp/original_format.tar.gz
       or you may request them directly from user services at : uso@daac.ornl.gov. 
       

       At the request of our user community, we have reformatted these data to
       be read more easily into a Geographic Information System (GIS).  Please 
       read below for a listing of files and their descriptions, and please see
       readme2.txt for more information and a brief description of how these
       files were created. 
      

FILES:
------

COMPANION FILES IN /comp:
------------------------

readme.txt - this file 

readme2.txt - additional documentation, describing GIS formats in more detail 

original_format.tar.gz - archive of original documentation and data files

zcontinent.txt - a listing/key of the FAO/UNESCO continent codes referenced in this 
                 data

zobler_106.txt - a listing/key of the Zobler soil types referenced in this data


DATA FILES IN /data:
--------------------

1. cont_code.asc - GRID ASCII file containing FAO continent codes (2-10); please see
                   zcontinent.txt in the /comp directory for the continent code 
                   key.  These values correspond to the volume numbers of the
                   nine major continental divisions in the FAO/UNESCO Soil Map
                   of the World Vols. 2-10 (1971-1981).

2. zobler106.asc - GRID ASCII file containing Zobler soil types (106); please see
                   zobler_106.txt in the /comp directory for the soil type key.
                   These values correspond to the sequence number of the soil types
                   in Zobler's (1986) World Soil Data File.  

3. new_soildata.csv - a comma delimited ASCII file that contains the depth, sand, 
                      silt, and clay data for each major continent (10), soil type
                      (106), and soil horizon (15).  

                      The sand, silt and clay data are stored as proportional values for
                      each soil horizon.  Please note that the arbitrary particle size 
                      distribution summing to 100% included for Histosols 
                      (entries 61-63) should not be used.  Instead, values reflecting 
                      the physical properties of organic soils and appropriate for 
                      specific research objectives should be inserted.  

                      The depth data are scaled in meters with the first value being
                      0m depth for each soil type and the subsequent values the contact
                      depths of contiguous horizons.  By definition, the depth variable
                      contains one extra value corresponding to the bottom depth of the
                      lowest horizon for each soil type.  Within this data set no soil
                      type had more than 14 soil horizons.  In cases when the number of
                      horizons in a soil type was less than 14, a value of -1.0 was used
                      to flag the end of the record for each soil type.  For example,
                      a soil type with 10 horizons has 10 data entries in the sand, silt,
                      and clay variables, and 11 data entries in the depth variable.
                      Records 11-15 in this example would be populated with -1.0 (except
                      for the depth variable which would be populated with -1.0 for 
                      records 12-15.)

                      Each record has the following attributes:
                      Zobler soil type [ztype] (106), continent code [cont]   
                      (10), profile number [profile] (15), contact depth of profile 
                      [depth], %sand [sand], %silt [silt], and %clay [clay]. 
                      Please note that the individual horizons for each soil type are 
                      from the Morphological, Chemical, and Physical Properties Appendix
                      in each of the nine volumes of the FAO/UNESCO Soil Map of the
                      World (1971-1981). 

Note: the following 15 gzipped export files include the same information as new_soildata.csv in a format that is easily imported into ARC/INFO GIS software.

4. profile1m.e00.gz - ESRI export file, global map of depth, sand, silt, and clay for
                      soil horizon 1.

5. profile2m.e00.gz - ESRI export file, global map of depth, sand, silt, and clay for
                      soil horizon 2.

6. profile3m.e00.gz - ESRI export file, global map of depth, sand, silt, and clay for
                      soil horizon 3.

7. profile4m.e00.gz - ESRI export file, global map of depth, sand silt, and clay for 
                      soil horizon 4.

8. profile5m.e00.gz - "" for soil horizon 5.

9. profile6m.e00.gz - "" for soil horizon 6.

10.profile7m.e00.gz - "" for soil horizon 7.

11.profile8m.e00.gz - "" for soil horizon 8.

12.profile9m.e00.gz - "" for soil horizon 9.

13.profile10m.e00.gz - "" for soil horizon 10.

14.profile11m.e00.gz - "" for soil horizon 11.

15.profile12m.e00.gz - "" for soil horizon 12. 

16.profile13m.e00.gz - "" for soil horizon 13.

17.profile14m.e00.gz - "" for soil horizon 14. 

18.profile15m.e00.gz - "" for soil horizon 15.

19.wrmodelii.asc - GRID ASCII file, global map used to prescribe water-holding
                   capacity (mm) in the GISS general circulation model (Model II)
                   (derived data set - was originally included as a companion file).

20.wrprof.asc - GRID ASCII file, global map of potential storage of water in the
                soil profile (mm) (derived data set - wwas originally included as a companion file).

21.wrroot.asc - GRID ASCII file, global map of the potential storage of water in the 
                root zone (mm) (derived data set - was originally included as a companion file).

22.wrtext.asc - GRID ASCII file, global map of potential storage of water derived
                from soil texture (mm) (derived data set - was originally included as a companion file).


GIS FORMATS:  
-------------------------------------------------------------------------
1. GRID ASCII - a single ASCII array with integer values. 
(Coordinates listed below are in decimal degrees.) The ASCII file consists 
of header information containing a set of keywords, followed by cell values in
row-major order. The file format is

<NCOLS xxx>
<NROWS xxx>
<XLLCORNER xxx>
<YLLCORNER xxx>
<CELLSIZE xxx>
{NODATA_VALUE xxx}
row 1
row 2
.
.
.
row n
where xxx is a number and the keyword NODATA_VALUE is optional and defaults to
-9999.  Row 1 of the data is at the top of the grid, row 2 is just under row 1,
and so on.  The end of each row of data from the grid is terminated with a
carriage return in the file.

First six lines of file (header):
ncols         360
nrows         180
xllcorner     -180
yllcorner     -90 
cellsize       1
NODATA_value  -9999

To import this file into ArcInfo, use the following command at an ARC prompt:

ASCIIGRID <in_ascii_file> <out_grid> {INT | FLOAT}

Arguments
<in_ascii_file> - the ASCII file to be converted.
<out_grid> - the user specified name of the grid to be created.
{INT | FLOAT} - the data type of the output grid.
INT - an integer grid will be created.
FLOAT - a floating-point grid will be created.

Note:  This data can also be imported into ArcView (with Spatial Analyst) and 
ArcGis as ASCII Raster data.

2. ESRI EXPORT FILE - this data can be imported into 
ARC/INFO GRID using the following command at an ARC prompt:

IMPORT <option> <interchange_file> <output>

Arguments
<option> - GRID
<interchange_file> - the name of the *e00 file to be converted
<output> - a user specified output file

Note: Utilities are available to import these files into ArcView and ArcGis.
                                                                                
                              
                                                                                
REFERENCES:                                                                      
----------
         Webb, Robert. W, Cynthia E. Rosenzweig, and Elissa R. Levine. 1992.
               A Global Data Set of Soil Particle Size Properties, NASA Technical 
               Memorandum 4286, 1992.   

         Webb, Robert W., Cynthia E. Rosenzweig, and Elissa R. Levine.  Specifying
               Land Surface Characteristics in General Circulation Models:  Soil
               Profile Data Set and Derived Water-Holding Capacities.

Note:  these references can be requested via email from: paleo@mail.ngdc.noaa.gov.
